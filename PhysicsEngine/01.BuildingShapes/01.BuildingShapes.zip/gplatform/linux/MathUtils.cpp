//
// Created by Gaëtan Blaise-Cazalet on 18/12/2023.
//

#include "MathUtils.hpp"
#include <cmath>

namespace gplatform {

    f32 Pow(f32 base, f32 exponent) {
        return pow(base, exponent);
    }

}

