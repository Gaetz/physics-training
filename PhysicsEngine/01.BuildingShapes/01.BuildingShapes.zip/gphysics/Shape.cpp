//
// Created by gaetz on 02/02/2025.
//

#include "Shape.hpp"

namespace gphysics {

}